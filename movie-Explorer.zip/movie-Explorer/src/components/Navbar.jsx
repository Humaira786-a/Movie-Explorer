import { Link, NavLink } from "react-router-dom";
import { FaHeart, FaSearch } from "react-icons/fa";
import { useEffect, useState } from "react";
import { useTheme } from "../contexts/ThemeContext";
import { FaMoon, FaSun } from "react-icons/fa";

function Navbar({ openSearch }) {
    const [scrolled, setScrolled] = useState(false);
    const { darkMode, setDarkMode } = useTheme();
  
  useEffect(() => {

    const handleScroll = () => {

        if (window.scrollY > 50) {
            setScrolled(true);
        } else {
            setScrolled(false);
        }

    };

    window.addEventListener("scroll", handleScroll);

    return () => {
        window.removeEventListener("scroll", handleScroll);
    };

}, []);
    return (
  <nav
className={`
fixed
top-0
left-0
w-full
z-50
transition-all
duration-300
backdrop-blur-md

${
    scrolled
        ? "bg-white/90 backdrop-blur-md shadow-xl  py-3"
        : "bg-transparent py-5"
}
`}
>
      <div
        className="
        max-w-7xl
        mx-auto
        px-4
        h-20
        flex
        items-center
        justify-between
        "
      >
        {/* Logo */}
        <Link
          to="/"
          className="
          flex
          items-center
          gap-4
          "
        >
          <img
    src="/clapperboard_3355866.png"
    alt="Logo"
    className={`
        transition-all
        duration-300
       
        ${scrolled ? "w-15 h-15" : "w-20 h-20"}
    `}
/>

          <span
    className={`
        font-bold
        text-red-500
        transition-all
        duration-300
        ${scrolled ? "text-2xl" : "text-3xl"}
    `}
>
    Movie<span className="text-red-300">Explorer</span>
</span>
        </Link>

        {/* Navigation */}
        <div className="flex items-center gap-3">

          <NavLink
            to="/"
            className={({ isActive }) =>
              `px-4 py-2 rounded-[5px] transition duration-300 ${
                isActive
                  ? "bg-red-600 font-bold text-white"
                  : "text-red-600 font-extrabold hover:text-white hover:bg-red-600"
              }`
            }
          >
            Home
          </NavLink>

          <NavLink
            to="/favorites"
            className={({ isActive }) =>
              `flex items-center gap-2 px-4 py-2 rounded-[5px] transition duration-300 ${
                isActive
                  ? "bg-red-600 text-white"
                  : "text-red-600 font-extrabold hover:text-white hover:bg-red-600"
              }`
            }
          >
            <FaHeart />
            Favorites
          </NavLink>

          <button
    onClick={openSearch}
    className="
        p-3
        rounded-full
    bg-red-600
        transition
    "
>
    <FaSearch />
</button>
          <button
  onClick={() => setDarkMode(!darkMode)}
  className="
    p-2
    rounded-full
    text-white
    bg-gray-800
    hover:bg-red-600
    transition
  "
>
    
  {darkMode ? <FaSun /> : <FaMoon />}
</button>

        </div>
      </div>
    </nav>
  );
}

export default Navbar;
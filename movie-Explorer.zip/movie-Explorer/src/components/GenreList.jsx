import { useState } from "react";
import {
  FaFire,
  FaGhost,
  FaHeart,
  FaDragon,
  FaLaugh,
  FaHatWizard,
  FaRocket,
  FaUserSecret,
  FaTheaterMasks,
  FaFilm
} from "react-icons/fa";

const genreIcons = {
  Action: <FaFire />,
  Adventure: <FaDragon />,
  Comedy: <FaLaugh />,
  Horror: <FaGhost />,
  Romance: <FaHeart />,
  Fantasy: <FaHatWizard />,
  "Science Fiction": <FaRocket />,
  Thriller: <FaUserSecret />,
  Drama: <FaTheaterMasks />,
  Animation: <FaFilm />,
};
const popularGenres = [
  { id: 28, name: "Action" },
  { id: 12, name: "Adventure" },
  { id: 35, name: "Comedy" },
  { id: 27, name: "Horror" },
  { id: 878, name: "Science Fiction" }, // important
  { id: 10749, name: "Romance" },
  { id: 16, name: "Animation" }
];

function GenreList({onSelect ,selectedGenre}) {


return (

<div
className="
flex
justify-center
gap-4
overflow-x-auto
px-6
py-5
bg-white
"
>

{
  popularGenres.map((genre) => (

    <div
      key={genre.id}
      className="flex flex-col items-center"
    >

      <button
        onClick={() => onSelect(genre.id)}
        className={`
          group
          w-24
          h-24
          rounded-full
          flex
          items-center
          justify-center
          text-white
          transition-all
          duration-300
          ${
            selectedGenre === genre.id
              ? "bg-red-600 scale-110 shadow-xl shadow-red-500/50"
              : "bg-gray-800 hover:bg-red-600 hover:scale-110 hover:-translate-y-2 hover:shadow-xl hover:shadow-red-500/50"
          }
        `}
      >
        <span
          className="
            text-4xl
            transition-transform
            duration-300
            group-hover:scale-125
            group-hover:rotate-12
          "
        >
          {genreIcons[genre.name]}
        </span>
      </button>
      <span
  className={`
    mt-3
    text-sm
    font-semibold
    whitespace-nowrap
    ${
      selectedGenre === genre.id
        ? "text-red-600"
        : "text-gray-800"
    }
  `}
>
  {genre.name}
</span>

     

    </div>

  ))
}


</div>

)

}


export default GenreList;